package com.cg.grid;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.cg.utilites.PropertyReader;

public class SwagLabsGrid {

	WebDriver driver;
	
	// Help to set the test case environment
	DesiredCapabilities cap = null;

	@Parameters({ "browser" })
	@Test
	public void CalorieDetails(String browser) throws IOException {
		
		// Configure different browsers
		if (browser.equals("chrome")) {
			cap = DesiredCapabilities.chrome();
		} else if (browser.equals("firefox")) {
			cap = DesiredCapabilities.firefox();
		} else if (browser.equals("ie")) {
			cap = DesiredCapabilities.internetExplorer();
		}

		driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), cap);

		driver.get(PropertyReader.getProperty("url"));

	}

}
