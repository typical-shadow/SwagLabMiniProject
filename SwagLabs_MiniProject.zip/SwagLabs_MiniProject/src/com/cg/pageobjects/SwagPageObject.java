package com.cg.pageobjects;

import java.io.File;
import java.io.FileInputStream;

import org.dom4j.Document;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SwagPageObject {

	private WebDriver driver = null;
	@FindBy(id = "user-name")
	private WebElement usernameElement;

	@FindBy(id = "password")
	private WebElement pwdElement;

	@FindBy(css = "input.btn_action")
	private WebElement loginBtn;

	@FindBy(linkText = "logout_sidebar_link")
	private WebElement logoutBtn;

	public SwagPageObject(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void standardUser(String stduser, String password) {

		usernameElement.sendKeys(stduser);
		pwdElement.sendKeys(password);
		loginBtn.click();

	}

	public void problemUser(String prblmUser, String password) {

		usernameElement.sendKeys(prblmUser);
		pwdElement.sendKeys(password);
		loginBtn.click();

	}

	public void logoutUser() {
		logoutBtn.click();

	}

}
