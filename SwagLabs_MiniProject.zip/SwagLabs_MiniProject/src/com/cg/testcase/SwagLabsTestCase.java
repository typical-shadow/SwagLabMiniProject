package com.cg.testcase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Hashtable;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.jetty.log.LogStream.STDOUT;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.cg.pageobjects.SwagPageObject;
import com.cg.utilites.PropertyReader;
import com.cg.utilites.SwagLabsExcelReader;

public class SwagLabsTestCase {

	String stduser;
	String prblmUser;
	String password;
	WebDriver driver;

	// Help to set the test case environment
	DesiredCapabilities cap = null;
	SwagPageObject swagObject = null;

	@Parameters({ "browser" })
	@BeforeMethod
	public void setUp(String browser) throws IOException {

		// Configure different browsers
		if (browser.equals("chrome")) {
			cap = DesiredCapabilities.chrome();
		} else if (browser.equals("firefox")) {
			cap = DesiredCapabilities.firefox();
		} else if (browser.equals("ie")) {
			cap = DesiredCapabilities.internetExplorer();
		}

		driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), cap);
		driver.get(PropertyReader.getProperty("url"));
		swagObject = new SwagPageObject(driver);

	}
	
	@BeforeClass
	public void xmlConfig() throws FileNotFoundException, DocumentException {
		
		String filename = System.getProperty("user.dir")+"/src/com/cg/testdata/UserDetails.xml";
		FileInputStream fileInputStream = new FileInputStream(new File(filename));
		SAXReader reader = new SAXReader();
		Document document = reader.read(fileInputStream);
		stduser = document.selectSingleNode("//Users/stduser").getText();
		prblmUser = document.selectSingleNode("//Users/problemuser").getText();
		password = document.selectSingleNode("//Users/password").getText();
		
	}
	
	@Test(priority=1)
	public void standardUserTestCase()
	{
		swagObject.standardUser(stduser, password);
	}
	
	@Test(priority=2)
	public void problemUserTestCase()
	{
		swagObject.problemUser(prblmUser, password);
	}
	
}
