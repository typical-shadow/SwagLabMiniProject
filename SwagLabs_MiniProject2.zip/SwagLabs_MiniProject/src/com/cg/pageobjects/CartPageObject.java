package com.cg.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.asserts.SoftAssert;

public class CartPageObject {

	private WebDriver driver;
	
	@FindBy(className = "subheader")
	private WebElement subHeading;

	@FindBy(className = "inventory_item_name")
	private WebElement cartItemTitle;

	@FindBy(linkText = "Continue Shopping")
	private WebElement continueShoppingBtn;

	@FindBy(linkText = "CHECKOUT")
	private WebElement checkoutBtn;

	@FindBy(id = "first-name")
	private WebElement fristNameElement;

	@FindBy(id = "last-name")
	private WebElement lastNameElement;

	@FindBy(id = "postal-code")
	private WebElement postalCodeElement;

	@FindBy(css = "input[value='CONTINUE']")
	private WebElement continueDetailsInfo;

	@FindBy(linkText = "FINISH")
	private WebElement finishBtn;

	@FindBy(className = "complete-header")
	private WebElement thankyoMsgElement;

	public CartPageObject(WebDriver driver) {
		this.driver = driver;
	}
	
	public void VerifySubHeading(String actual) {

		String expected = subHeading.getText();
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(expected, actual);
		softAssert.assertAll();

	}

	public void checkoutBtn() {
		checkoutBtn.click();

	}

	public void setUserInfo(String fname, String lname, String postalCode) {
		fristNameElement.sendKeys(fname);
		lastNameElement.sendKeys(lname);
		postalCodeElement.sendKeys(postalCode);

	}

	public void clickOnContinue() {
		continueDetailsInfo.click();

	}

	public void clickOnFinish() {
		finishBtn.click();

	}

	public void finshPage() {
		String expected = "THANK YOU FOR YOUR ORDER";
		String actual = thankyoMsgElement.getText();
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(expected, actual);
		softAssert.assertAll();

	}

}
