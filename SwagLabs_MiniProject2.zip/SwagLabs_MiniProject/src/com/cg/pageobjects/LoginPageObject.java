package com.cg.pageobjects;


import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.asserts.SoftAssert;

public class LoginPageObject {

	private WebDriver driver = null;
	@FindBy(id = "user-name")
	private WebElement usernameElement;

	@FindBy(id = "password")
	private WebElement pwdElement;

	@FindBy(css = "input.btn_action")
	private WebElement loginBtn;

	@FindBy(linkText = "logout_sidebar_link")
	private WebElement logoutBtn;
	
	@FindBy(xpath  = "//*[@id=\"login_button_container\"]/div/form/h3")
	private WebElement errorElement;

	public LoginPageObject(WebDriver driver) {
		this.driver = driver;
	}

	public void standardUserLogin(String stduser, String password) {

		usernameElement.sendKeys(stduser);
		pwdElement.sendKeys(password);
		loginBtn.click();

	}

	public void problemUserLogin(String prblmUser, String password) {

		usernameElement.sendKeys(prblmUser);
		pwdElement.sendKeys(password);
		loginBtn.click();

	}

	public void logoutUser() {
		logoutBtn.click();

	}

	public void lockedUserLogin(String prblmUser, String password) {
		usernameElement.sendKeys(prblmUser);
		pwdElement.sendKeys(password);
		loginBtn.click();
		
	}

	public void verfifylockeduserMessage() {
		String expected = "Epic sadface: Sorry, this user has been locked out.";
		System.out.println(expected);
		String actual = errorElement.getText();
		System.out.println(actual);
		
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(expected, actual);
		softAssert.assertAll();
		
		
	}

	public void loginTest(Hashtable<String, String> ht) {
		
		usernameElement.sendKeys(ht.get("username"));
		pwdElement.sendKeys(ht.get("password"));
		loginBtn.click();
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertTrue(driver.getCurrentUrl().matches("https://www.saucedemo.com/inventory.html"), "Invaid Credentials");
		softAssert.assertAll();
		
	}

}
