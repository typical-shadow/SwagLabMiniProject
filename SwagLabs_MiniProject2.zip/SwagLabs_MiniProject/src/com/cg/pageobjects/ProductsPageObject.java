package com.cg.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class ProductsPageObject {

	private WebDriver driver;

	// @FindBy(id ="item_1_title_link")
	// private WebElement itemTitle1;

	@FindBy(id = "item_4_title_link")
	private WebElement itemTitle4;

	@FindBy(className = "product_sort_container")
	private WebElement filterElement;

	@FindBy(className = "inventory_details_name")
	private WebElement itemProductTitle;
	
	@FindBy(xpath = "//span[@class='fa-layers-counter shopping_cart_badge']")
	private WebElement cartNoIcon;
	
	@FindBy(xpath = "//button[@class='btn_primary btn_inventory']")
	private WebElement addToCartButton;

	@FindBy(className = "inventory_details_back_button")
	private WebElement backBtn;

	@FindBy(className = "shopping_cart_container")
	private WebElement cartIcon;
	
	@FindBy(className  = "product_label")
	private WebElement productLabel;
	
	@FindBy(id = "inventory_sidebar_link")
	private WebElement allItemsLink;
	
	@FindBy(id = "logout_sidebar_link")
	private WebElement logoutLink;
	
	@FindBy(id = "reset_sidebar_link")
	private WebElement resetAppLink;
	
	@FindBy(className = "bm-burger-button")
	private WebElement burgerIcon;


	public ProductsPageObject(WebDriver driver) {
		this.driver = driver;
	}

	public void clickOnItem4() {

		String productTitle = itemTitle4.getText();
		itemTitle4.click();
		String itemTitle = itemProductTitle.getText();

		
		Assert.assertEquals(productTitle, itemTitle);
		

	}

	public void clickOnBack() {
		backBtn.click();

	}

	public void clickOnCartIcon() {
		cartIcon.click();
		
	}

	public void addToCart() {
		addToCartButton.click();
		
	}

	public void clickOnAllItem() throws InterruptedException {
		Thread.sleep(2000);
		burgerIcon.click();
		Thread.sleep(2000);
		allItemsLink.click();
		Thread.sleep(2000);
		String expected = productLabel.getText();
		String actual = "Products";
		Assert.assertTrue(expected.matches(actual), "Failed to Navigate Product Page..");
		
	}

	public void logoutUser() {
		logoutLink.click();
		
	}

	public void checkResetLink() throws InterruptedException {
		SoftAssert softAssert = new SoftAssert();
		addToCartButton.click();
		String cartBtnValue = addToCartButton.getText();
		String beforeReset = cartNoIcon.getText();
		burgerIcon.click();
		Thread.sleep(2000);
		resetAppLink.click();
//		String afterReset = cartNoIcon.getText();
		
//		softAssert.assert;
		Thread.sleep(2000);
		softAssert.assertTrue(cartBtnValue.matches(addToCartButton.getText()), "Reset Failed..");
		softAssert.assertAll();
		
		
	
		
		
	}
	
	
	
	
}
