package com.cg.testcase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Hashtable;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.jetty.log.LogStream.STDOUT;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.cg.pageobjects.CartPageObject;
import com.cg.pageobjects.ProductsPageObject;
import com.cg.pageobjects.LoginPageObject;
import com.cg.utilites.PropertyReader;
import com.cg.utilites.SwagLabsExcelReader;
import com.cg.utilites.UserDetailsReader;

public class SwagLabsTestCase extends TestBase {

	private LoginPageObject loginObject = null;
	private ProductsPageObject productObject = null;
	private CartPageObject cartObject = null;

	@Test(priority = 1, dataProvider = "getUserCredentials")
	public void loginTestCase(Hashtable<String, String> ht) {

		loginObject = PageFactory.initElements(driver, LoginPageObject.class);
		loginObject.loginTest(ht);

	}

	@Test(priority = 2)
	public void standardUserTestCase() {

		loginObject = PageFactory.initElements(driver, LoginPageObject.class);
		loginObject.standardUserLogin(stduser, password);

		productObject = PageFactory.initElements(driver, ProductsPageObject.class);
		productObject.clickOnItem4();
		productObject.addToCart();
		productObject.clickOnBack();
		productObject.clickOnCartIcon();

		cartObject = PageFactory.initElements(driver, CartPageObject.class);
		cartObject.VerifySubHeading("Your Cart");
		cartObject.checkoutBtn();
		cartObject.VerifySubHeading("Checkout: Your Information");
		cartObject.setUserInfo("katherin", "Macs", "400078");
		cartObject.clickOnContinue();
		cartObject.VerifySubHeading("Checkout: Overview");
		cartObject.clickOnFinish();
		cartObject.VerifySubHeading("Finish");
		cartObject.finshPage();

	}

	@Test(priority = 3)
	public void lockedOutUserTest() {
		loginObject = PageFactory.initElements(driver, LoginPageObject.class);

		loginObject.lockedUserLogin(lockedUser, password);
		loginObject.verfifylockeduserMessage();

	}

	@Test(priority = 4)
	public void problemUserTestCase() {

		loginObject = PageFactory.initElements(driver, LoginPageObject.class);
		loginObject.problemUserLogin(prblmUser, password);

		productObject = PageFactory.initElements(driver, ProductsPageObject.class);
		productObject.clickOnItem4();
		productObject.addToCart();
		productObject.clickOnBack();
		productObject.clickOnCartIcon();

		cartObject = PageFactory.initElements(driver, CartPageObject.class);
		cartObject.VerifySubHeading("Your Cart");
		cartObject.checkoutBtn();
		cartObject.VerifySubHeading("Checkout: Your Information");
		cartObject.setUserInfo("katherin", "Macs", "400078");
		cartObject.clickOnContinue();
		cartObject.VerifySubHeading("Checkout: Overview");
		cartObject.clickOnFinish();
		cartObject.VerifySubHeading("Finish");
		cartObject.finshPage();

	}

//	@Test(priority = 4)
//	public void performanceUserTestCase() {
//
//	}
	
	@Test(priority = 5)
	public void productMenuLinkTestCase() throws InterruptedException {
		
		loginObject = PageFactory.initElements(driver, LoginPageObject.class);
		loginObject.standardUserLogin(stduser, password);
		
		productObject = PageFactory.initElements(driver, ProductsPageObject.class);
		productObject.clickOnItem4();
		productObject.clickOnAllItem();
		
		productObject.checkResetLink();
//		productObject.logoutUser();
		
		
		
		
		
	}

	@DataProvider
	public Object[][] getUserCredentials() throws IOException {

		String filename = "UserDetails.xlsx";
		String filepath = System.getProperty("user.dir") + "/src/com/cg/testdata";
		String sheetname = "loginDetails";
		return UserDetailsReader.ReadExcelData(filepath, filename, sheetname);

	}

}
