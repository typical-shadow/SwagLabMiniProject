package com.cg.testcase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import com.cg.pageobjects.LoginPageObject;
import com.cg.utilites.PropertyReader;

public class TestBase {

	public String stduser;
	public String prblmUser;
	public String lockedUser;
	public String password;
	public WebDriver driver;

	// Help to set the test case environment
	private DesiredCapabilities cap = null;
	

	@Parameters({ "browser" })
	@BeforeMethod
	public void setUp(String browser) throws IOException {

		// Configure different browsers
		if (browser.equals("chrome")) {
			cap = DesiredCapabilities.chrome();
		} else if (browser.equals("firefox")) {
			cap = DesiredCapabilities.firefox();
		} else if (browser.equals("ie")) {
			cap = DesiredCapabilities.internetExplorer();
		}

		driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), cap);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(PropertyReader.getProperty("url"));


	}
	
	@BeforeClass
	public void xmlConfig() throws FileNotFoundException, DocumentException {
		
		String filename = System.getProperty("user.dir")+"/src/com/cg/testdata/UserDetails.xml";
		FileInputStream fileInputStream = new FileInputStream(new File(filename));
		SAXReader reader = new SAXReader();
		Document document = reader.read(fileInputStream);
		stduser = document.selectSingleNode("//Users/stduser").getText();
		prblmUser = document.selectSingleNode("//Users/problemuser").getText();
		password = document.selectSingleNode("//Users/password").getText();
		lockedUser = document.selectSingleNode("//Users/lockeduser").getText();
		
	}
	
	@AfterMethod
	public void programTermination() {
//		driver.quit();
	}

	
}
