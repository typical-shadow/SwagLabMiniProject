package com.cg.utilites;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Hashtable;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class SwagLabsExcelReader {

	public static Object[][] ReadUserDetails(String filepath, String filename, String sheetname) throws IOException {

		File file = new File(filepath + "/" + filename);
		FileInputStream inputStream = new FileInputStream(file);
		// excel has 2 file format xls ana xlsx
		// for xls we use HSSFWorkbook and xlsx we use XSSFWorkbook
		XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
		Sheet sheet = workbook.getSheet(sheetname);

		int rowcount = sheet.getLastRowNum();// 3 data rows + 1 colrow = 3

		Object[][] data = new Object[rowcount][1];

		Row keyRow = sheet.getRow(0);
		Hashtable<String, String> rec = null;

		for (int r = 1; r < rowcount + 1; r++) {
			Row row = sheet.getRow(r);// get the current row
			rec = new Hashtable<String, String>();
			for (int c = 0; c < row.getLastCellNum(); c++) {
				String key = keyRow.getCell(c).getStringCellValue();
				String val = row.getCell(c).getStringCellValue();
				rec.put(key, val);
				System.out.println(key + ":" + val);
			}
			data[r - 1][0] = rec;
		}

		return data;

	}

}
